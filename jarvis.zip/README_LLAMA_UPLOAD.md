# JARVIS — `llama.cpp` Upload & NDK Integration Guide
**Engineered by Prince Priyadarshi**

To enable native C++ GGUF inference with `SmolLM2-360M-Instruct-Q4_K_M.gguf`, upload your `llama.cpp` source files into the exact workspace path below:

## Exact Directory Tree for `llama.cpp`

```text
/ (Workspace Root)
└── app/
    └── src/
        └── main/
            └── cpp/
                ├── CMakeLists.txt                  <-- (Already generated: auto-detects llama.cpp)
                ├── native-lib.cpp                  <-- (Already generated: JNI Bridge + ChatML Engine)
                └── llama.cpp/                      <-- UPLOAD YOUR llama.cpp REPOSITORY HERE
                    ├── CMakeLists.txt              <-- Required: root CMakeLists.txt of llama.cpp
                    ├── ggml/                       <-- Required: ggml tensor library directory
                    │   ├── CMakeLists.txt
                    │   ├── include/
                    │   │   ├── ggml.h
                    │   │   ├── ggml-alloc.h
                    │   │   ├── ggml-backend.h
                    │   │   └── ggml-cpu.h
                    │   └── src/
                    │       ├── CMakeLists.txt
                    │       ├── ggml.c
                    │       ├── ggml-alloc.c
                    │       ├── ggml-backend.cpp
                    │       ├── ggml-quants.c
                    │       └── ggml-cpu/
                    ├── include/                    <-- Required: public llama.h header
                    │   └── llama.h
                    ├── src/                        <-- Required: core llama.cpp implementation
                    │   ├── CMakeLists.txt
                    │   ├── llama.cpp
                    │   ├── llama-vocab.cpp
                    │   ├── llama-grammar.cpp
                    │   ├── llama-sampling.cpp
                    │   └── ...
                    └── common/                     <-- Optional/Recommended: common helpers
                        ├── CMakeLists.txt
                        ├── common.h
                        ├── common.cpp
                        └── sampling.h
```

## Required Subfolders & Files Checklist
1. **`app/src/main/cpp/llama.cpp/CMakeLists.txt`** — The top-level CMake file from `llama.cpp` that defines the `llama` and `ggml` targets.
2. **`app/src/main/cpp/llama.cpp/ggml/`** — Contains `CMakeLists.txt`, `include/` (`ggml.h`, `ggml-backend.h`, `ggml-cpu.h`), and `src/` (ARM64 NEON / dotprod kernels).
3. **`app/src/main/cpp/llama.cpp/include/`** — Must contain `llama.h`.
4. **`app/src/main/cpp/llama.cpp/src/`** — Must contain `llama.cpp` and internal implementation sources.
5. **`app/src/main/cpp/llama.cpp/common/`** — Common utilities if referenced by your `llama.cpp` revision.

## How the Resilient Build Works
- **When `app/src/main/cpp/llama.cpp/CMakeLists.txt` is present:** CMake automatically sets `-DGGML_OPENMP=OFF`, `-DLLAMA_CURL=OFF`, `-DBUILD_SHARED_LIBS=OFF`, defines `HAVE_LLAMA_CPP=1`, compiles `llama` and `ggml` for `arm64-v8a` (Cortex-A73 / Exynos 7884 tuned), and links them into `libjarvis-native.so`.
- **Before `llama.cpp` is uploaded (Cloud Build Safe Mode):** The project compiles cleanly with zero errors so you can immediately install the APK onto your Samsung Galaxy A10, download the 36 MB offline Vosk voice pack, select your `.gguf` file from `/Download/`, and test every single offline voice orchestration action right away.
