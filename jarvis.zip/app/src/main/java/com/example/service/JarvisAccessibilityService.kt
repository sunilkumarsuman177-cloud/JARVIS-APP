package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class JarvisAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isConnected.value = true
        JarvisStateBus.appendLog("ACCESSIBILITY", "JarvisAccessibilityService connected and active.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Lightweight passive hook: zero overhead while idle to preserve Galaxy A10 2GB RAM
    }

    override fun onInterrupt() {
        // No-op
    }

    override fun onDestroy() {
        if (instance === this) {
            instance = null
        }
        _isConnected.value = false
        super.onDestroy()
    }

    /**
     * Clicks any visible screen node or button matching `targetText` (case-insensitive).
     */
    fun clickByText(targetText: String): Boolean {
        val query = targetText.trim()
        if (query.isEmpty()) return false

        val root = rootInActiveWindow ?: return false
        try {
            // 1. Direct Accessibility framework text search
            val directMatches = root.findAccessibilityNodeInfosByText(query)
            if (!directMatches.isNullOrEmpty()) {
                for (node in directMatches) {
                    if (performClickUpHierarchy(node)) {
                        return true
                    }
                }
            }

            // 2. Deep recursive fuzzy traversal checking text & contentDescription
            val lowerQuery = query.lowercase(Locale.US)
            val fallbackMatch = findNodeRecursive(root, lowerQuery)
            if (fallbackMatch != null) {
                return performClickUpHierarchy(fallbackMatch)
            }
        } catch (_: Exception) {
            return false
        }
        return false
    }

    /**
     * Executes global navigation or vertical scroll gestures:
     * home | back | recents | notifications | scroll_down | scroll_up
     */
    fun executeNavigation(target: String): Boolean {
        return when (target.trim().lowercase(Locale.US)) {
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "recents", "recent" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "notifications", "notification" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "scroll_down" -> performScroll(forward = true)
            "scroll_up" -> performScroll(forward = false)
            else -> false
        }
    }

    private fun performClickUpHierarchy(node: AccessibilityNodeInfo?): Boolean {
        var current = node
        var depth = 0
        while (current != null && depth < 6) {
            if (current.isClickable && current.isEnabled) {
                return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            current = current.parent
            depth++
        }
        return node?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }

    private fun findNodeRecursive(
        node: AccessibilityNodeInfo?,
        lowerQuery: String
    ): AccessibilityNodeInfo? {
        if (node == null) return null
        val nodeText = node.text?.toString()?.lowercase(Locale.US).orEmpty()
        val nodeDesc = node.contentDescription?.toString()?.lowercase(Locale.US).orEmpty()

        if (nodeText.contains(lowerQuery) || nodeDesc.contains(lowerQuery)) {
            return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val match = findNodeRecursive(child, lowerQuery)
            if (match != null) return match
        }
        return null
    }

    private fun performScroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow
        if (root != null) {
            val scrollable = findScrollableNode(root)
            if (scrollable != null) {
                val action = if (forward) {
                    AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                } else {
                    AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                }
                if (scrollable.performAction(action)) {
                    return true
                }
            }
        }

        // Gesture fallback for apps using custom canvases/lists
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val displayMetrics = resources.displayMetrics
            val centerX = displayMetrics.widthPixels / 2f
            val startY = if (forward) displayMetrics.heightPixels * 0.75f else displayMetrics.heightPixels * 0.25f
            val endY = if (forward) displayMetrics.heightPixels * 0.25f else displayMetrics.heightPixels * 0.75f

            val swipePath = Path().apply {
                moveTo(centerX, startY)
                lineTo(centerX, endY)
            }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(swipePath, 0L, 280L))
                .build()
            return dispatchGesture(gesture, null, null)
        }
        return false
    }

    private fun findScrollableNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val found = findScrollableNode(node.getChild(i))
            if (found != null) return found
        }
        return null
    }

    companion object {
        @Volatile
        var instance: JarvisAccessibilityService? = null
            private set

        private val _isConnected = MutableStateFlow(false)
        val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()
    }
}
