package com.example.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.JarvisPreferences
import com.example.engine.LlamaBridge
import com.example.engine.PhoneOrchestrator
import com.example.engine.VoskModelManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.util.Locale

class JarvisService : Service(), RecognitionListener, TextToSpeech.OnInitListener {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var prefs: JarvisPreferences
    private lateinit var orchestrator: PhoneOrchestrator

    private var tts: TextToSpeech? = null
    private var ttsReady: Boolean = false
    private var toneGenerator: ToneGenerator? = null

    private var voskModel: Model? = null
    private var speechService: SpeechService? = null
    private var voskInitInProgress: Boolean = false

    private var inactivityTimerJob: Job? = null
    private var telemetryLoopJob: Job? = null
    private var lastWakeTriggerTimestampMs: Long = 0L

    override fun onCreate() {
        super.onCreate()
        prefs = JarvisPreferences(this)
        orchestrator = PhoneOrchestrator(this)

        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 85)
        } catch (_: Throwable) {
            toneGenerator = null
        }

        try {
            tts = TextToSpeech(applicationContext, this)
        } catch (_: Throwable) {
            tts = null
        }

        // Ensure GGUF brain starts unloaded (0 MB Idle RAM) in SLEEPING state
        LlamaBridge.freeModel()

        syncConfigToStateBus()
        startAsForegroundService()
        startRamTelemetryLoop()
        initializeOrRefreshVoskEar()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForegroundService()

        when (intent?.action) {
            ACTION_MANUAL_WAKE -> {
                val snap = JarvisStateBus.snapshot.value
                if (snap.state == JarvisOrchestratorState.SLEEPING) {
                    wakeBrainAndListen(triggerReason = "Manual Wake Override", trailingCommand = null)
                } else {
                    resetInactivityTimer()
                }
            }
            ACTION_MANUAL_SLEEP -> {
                sleepBrainAndReclaimRam(reason = "Manual Sleep Override")
            }
            ACTION_RELOAD_CONFIG -> {
                syncConfigToStateBus()
                val snap = JarvisStateBus.snapshot.value
                if (snap.state == JarvisOrchestratorState.ONLINE) {
                    resetInactivityTimer()
                }
                updateForegroundNotification()
                JarvisStateBus.appendLog(
                    "HOT_RELOAD",
                    "Wake line updated to \"${prefs.getWakeLine()}\" | Auto-sleep: ${prefs.getInactivityTimeoutSec()}s"
                )
            }
            ACTION_RELOAD_VOSK -> {
                initializeOrRefreshVoskEar(forceReload = true)
            }
            ACTION_EXECUTE_TEXT_COMMAND -> {
                val cmd = intent.getStringExtra(EXTRA_COMMAND_TEXT)?.trim().orEmpty()
                if (cmd.isNotEmpty()) {
                    handleIncomingUtterance(cmd, fromVoiceEar = false)
                }
            }
            else -> {
                syncConfigToStateBus()
                initializeOrRefreshVoskEar(forceReload = false)
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val res = tts?.setLanguage(Locale.US)
            ttsReady = (res != TextToSpeech.LANG_MISSING_DATA && res != TextToSpeech.LANG_NOT_SUPPORTED)
            tts?.setSpeechRate(1.05f)
        }
    }

    private fun speakOffline(text: String) {
        if (text.isBlank()) return
        if (ttsReady) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_utt_${System.nanoTime()}")
        }
    }

    private fun playWakeTone() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP2, 160)
        } catch (_: Throwable) {
        }
    }

    private fun playSleepTone() {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_NACK, 200)
        } catch (_: Throwable) {
        }
    }

    private fun syncConfigToStateBus() {
        val wakeLine = prefs.getWakeLine()
        val timeoutSec = prefs.getInactivityTimeoutSec()
        val ggufPath = prefs.getGgufModelPath()
        val ggufName = prefs.getGgufDisplayName()
        val ggufMeta = LlamaBridge.inspectGgufFile(File(ggufPath))
        val voskInstalled = VoskModelManager.isVoskModelInstalled(this)

        JarvisStateBus.updateState { current ->
            current.copy(
                serviceRunning = true,
                wakeLine = wakeLine,
                inactivityTimeoutSec = timeoutSec,
                ggufModelPath = ggufPath,
                ggufDisplayName = ggufName,
                ggufFileExists = ggufMeta.exists,
                ggufSizeMb = ggufMeta.sizeMb,
                ggufHeaderValid = ggufMeta.validMagic,
                engineInfo = LlamaBridge.getEngineStatusBanner(ggufMeta),
                voskReady = voskInstalled,
                voskStatusText = when {
                    speechService != null -> "Vosk Ear Active (Listening offline < 45 MB RAM)"
                    voskInstalled -> "Vosk Voice Pack Installed (Grant Mic to listen)"
                    else -> "Offline Voice Pack not installed yet (36 MB download)"
                }
            )
        }
    }

    private fun initializeOrRefreshVoskEar(forceReload: Boolean = false) {
        if (voskInitInProgress) return
        if (speechService != null && !forceReload) return

        val hasMicPerm = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        val voskInstalled = VoskModelManager.isVoskModelInstalled(this)
        if (!voskInstalled) {
            JarvisStateBus.updateState {
                it.copy(
                    voskReady = false,
                    voskListening = false,
                    voskStatusText = "Tap 'Download Offline Voice Pack (36 MB)' to activate Ear"
                )
            }
            return
        }

        if (!hasMicPerm) {
            JarvisStateBus.updateState {
                it.copy(
                    voskReady = true,
                    voskListening = false,
                    voskStatusText = "Vosk Pack Ready — Grant Microphone permission to start Ear"
                )
            }
            return
        }

        voskInitInProgress = true
        serviceScope.launch {
            try {
                stopVoskStreamInternal()
                val modelDir = VoskModelManager.getModelDir(this@JarvisService)
                JarvisStateBus.updateState {
                    it.copy(voskStatusText = "Loading Vosk acoustic model from filesDir/vosk-model...")
                }

                val loadedModel = withContext(Dispatchers.IO) {
                    Model(modelDir.absolutePath)
                }
                voskModel = loadedModel

                val recognizer = Recognizer(loadedModel, 16000.0f)
                val service = SpeechService(recognizer, 16000.0f)
                service.startListening(this@JarvisService)
                speechService = service

                JarvisStateBus.updateState {
                    it.copy(
                        voskReady = true,
                        voskListening = true,
                        voskStatusText = "Vosk Ear Online • 16kHz Offline Stream Active"
                    )
                }
                JarvisStateBus.appendLog("EAR", "Vosk Offline Ear listening for wake line: \"${prefs.getWakeLine()}\"")
                updateForegroundNotification()
            } catch (t: Throwable) {
                JarvisStateBus.updateState {
                    it.copy(
                        voskListening = false,
                        voskStatusText = "Vosk init warning: ${t.localizedMessage ?: "check audio input"}"
                    )
                }
                JarvisStateBus.appendLog("WARN", "Vosk init error: ${t.localizedMessage}")
            } finally {
                voskInitInProgress = false
            }
        }
    }

    private fun stopVoskStreamInternal() {
        try {
            speechService?.stop()
            speechService?.shutdown()
        } catch (_: Throwable) {
        }
        speechService = null
        try {
            voskModel?.close()
        } catch (_: Throwable) {
        }
        voskModel = null
    }

    // --- Vosk RecognitionListener Callbacks ---

    override fun onPartialResult(hypothesis: String?) {
        if (hypothesis.isNullOrBlank()) return
        val partialText = parseVoskField(hypothesis, "partial")
        if (partialText.isBlank()) return

        val snap = JarvisStateBus.snapshot.value
        if (snap.state == JarvisOrchestratorState.SLEEPING) {
            val wakeLine = prefs.getWakeLine()
            val now = System.currentTimeMillis()
            if (partialText.contains(wakeLine, ignoreCase = true) && (now - lastWakeTriggerTimestampMs > 2200L)) {
                lastWakeTriggerTimestampMs = now
                // Reset recognizer stream so the wake word isn't re-triggered on final result
                speechService?.reset()
                wakeBrainAndListen(
                    triggerReason = "Wake phrase heard: \"$wakeLine\"",
                    trailingCommand = null
                )
            }
        }
    }

    override fun onResult(hypothesis: String?) {
        if (hypothesis.isNullOrBlank()) return
        val text = parseVoskField(hypothesis, "text")
        if (text.isBlank()) return
        handleIncomingUtterance(text, fromVoiceEar = true)
    }

    override fun onFinalResult(hypothesis: String?) {
        if (hypothesis.isNullOrBlank()) return
        val text = parseVoskField(hypothesis, "text")
        if (text.isBlank()) return
        handleIncomingUtterance(text, fromVoiceEar = true)
    }

    override fun onError(exception: Exception?) {
        JarvisStateBus.appendLog("EAR_WARN", "Vosk stream error: ${exception?.localizedMessage ?: "unknown"}")
    }

    override fun onTimeout() {
        speechService?.startListening(this)
    }

    private fun parseVoskField(jsonStr: String, key: String): String {
        return try {
            JSONObject(jsonStr).optString(key, "").trim().lowercase(Locale.US)
        } catch (_: Exception) {
            ""
        }
    }

    private fun handleIncomingUtterance(rawUtterance: String, fromVoiceEar: Boolean) {
        val utterance = rawUtterance.trim()
        if (utterance.isEmpty()) return

        val wakeLine = prefs.getWakeLine()
        val snap = JarvisStateBus.snapshot.value

        if (snap.state == JarvisOrchestratorState.SLEEPING) {
            if (!fromVoiceEar) {
                // Direct UI command wakes the brain automatically and executes
                val cleanedCmd = stripWakePrefix(utterance, wakeLine)
                wakeBrainAndListen(
                    triggerReason = "Direct Command Wake",
                    trailingCommand = cleanedCmd.ifEmpty { utterance }
                )
                return
            }

            if (utterance.contains(wakeLine, ignoreCase = true)) {
                val now = System.currentTimeMillis()
                if (now - lastWakeTriggerTimestampMs > 1500L) {
                    lastWakeTriggerTimestampMs = now
                    val trailing = extractTrailingCommand(utterance, wakeLine)
                    wakeBrainAndListen(
                        triggerReason = "Heard Wake Line: \"$utterance\"",
                        trailingCommand = trailing.takeIf { it.isNotBlank() }
                    )
                }
            }
        } else if (snap.state == JarvisOrchestratorState.ONLINE) {
            val commandToRun = stripWakePrefix(utterance, wakeLine).trim()
            if (commandToRun.isEmpty()) {
                // User just repeated "hey jarvis" while already awake -> reset timer
                resetInactivityTimer()
                playWakeTone()
                return
            }
            executeAwakeCommand(commandToRun)
        }
    }

    private fun wakeBrainAndListen(triggerReason: String, trailingCommand: String?) {
        serviceScope.launch {
            val ggufPath = prefs.getGgufModelPath()
            JarvisStateBus.updateState {
                it.copy(
                    state = JarvisOrchestratorState.WAKING_BRAIN,
                    lastActionFeedback = "Loading GGUF Brain (n_ctx=512, n_threads=4)..."
                )
            }
            JarvisStateBus.appendLog("WAKE", "$triggerReason -> Waking GGUF Brain...")
            updateForegroundNotification()

            val loadedOk = withContext(Dispatchers.IO) {
                LlamaBridge.loadModel(ggufPath)
            }

            val timeoutSec = prefs.getInactivityTimeoutSec()
            JarvisStateBus.updateState {
                it.copy(
                    state = JarvisOrchestratorState.ONLINE,
                    brainLoadedInRam = loadedOk,
                    remainingWakeSeconds = timeoutSec,
                    lastActionFeedback = "Brain ONLINE • Auto-sleep in ${timeoutSec}s"
                )
            }
            playWakeTone()
            JarvisStateBus.appendLog(
                "BRAIN",
                "GGUF Brain ONLINE (n_ctx=512, n_threads=4, n_batch=128). 60s countdown started."
            )
            resetInactivityTimer()
            updateForegroundNotification()

            if (!trailingCommand.isNullOrBlank()) {
                executeAwakeCommand(trailingCommand)
            } else {
                speakOffline("Online")
            }
        }
    }

    private fun executeAwakeCommand(commandText: String) {
        serviceScope.launch {
            // 1. Reset 60s inactivity timer back to full timeout on every command
            resetInactivityTimer()

            JarvisStateBus.updateState {
                it.copy(
                    state = JarvisOrchestratorState.EXECUTING,
                    lastHeardPhrase = commandText,
                    lastActionFeedback = "Inferring ChatML JSON for: \"$commandText\""
                )
            }
            JarvisStateBus.appendLog("HEARD", "\"$commandText\"")

            // 2. Run nativeInfer() on background thread
            val jsonOutput = withContext(Dispatchers.Default) {
                LlamaBridge.infer(commandText)
            }

            JarvisStateBus.appendLog("JSON", jsonOutput, isJson = true)

            // 3. Execute JSON action on phone
            val outcome = orchestrator.executeJsonCommand(jsonOutput) { speech ->
                speakOffline(speech)
            }

            // 4. Return to ONLINE state while countdown continues
            val timeoutSec = prefs.getInactivityTimeoutSec()
            JarvisStateBus.updateState {
                it.copy(
                    state = JarvisOrchestratorState.ONLINE,
                    lastExecutedJson = jsonOutput,
                    lastActionFeedback = outcome.summary,
                    remainingWakeSeconds = timeoutSec
                )
            }
            resetInactivityTimer()
            updateForegroundNotification()
        }
    }

    private fun resetInactivityTimer() {
        inactivityTimerJob?.cancel()
        val totalSeconds = prefs.getInactivityTimeoutSec()
        JarvisStateBus.updateState {
            it.copy(
                inactivityTimeoutSec = totalSeconds,
                remainingWakeSeconds = totalSeconds
            )
        }

        inactivityTimerJob = serviceScope.launch {
            var remaining = totalSeconds
            while (remaining > 0 && isActive) {
                delay(1000L)
                remaining--
                JarvisStateBus.updateState { current ->
                    if (current.state == JarvisOrchestratorState.ONLINE ||
                        current.state == JarvisOrchestratorState.EXECUTING
                    ) {
                        current.copy(remainingWakeSeconds = remaining)
                    } else {
                        current
                    }
                }
                if (remaining % 5 == 0 || remaining <= 5) {
                    updateForegroundNotification()
                }
            }
            if (remaining <= 0 && isActive) {
                sleepBrainAndReclaimRam(reason = "${totalSeconds}s Inactivity Timeout Reached")
            }
        }
    }

    private fun sleepBrainAndReclaimRam(reason: String) {
        inactivityTimerJob?.cancel()
        inactivityTimerJob = null

        serviceScope.launch {
            withContext(Dispatchers.IO) {
                LlamaBridge.freeModel()
                System.gc()
            }
            playSleepTone()

            JarvisStateBus.updateState {
                it.copy(
                    state = JarvisOrchestratorState.SLEEPING,
                    brainLoadedInRam = false,
                    remainingWakeSeconds = 0,
                    lastActionFeedback = "SLEEPING (0 MB Brain RAM • Listening for \"${prefs.getWakeLine()}\")"
                )
            }
            JarvisStateBus.appendLog(
                "SLEEP",
                "$reason -> nativeFreeModel() called. Reclaimed GGUF RAM. Ear listening for \"${prefs.getWakeLine()}\"."
            )
            updateForegroundNotification()
        }
    }

    private fun startRamTelemetryLoop() {
        telemetryLoopJob?.cancel()
        telemetryLoopJob = serviceScope.launch {
            while (isActive) {
                val (pssMb, availMb, totalMb) = JarvisStateBus.sampleProcessRamMb(this@JarvisService)
                val snap = JarvisStateBus.snapshot.value
                // If GGUF is loaded via Kotlin/fallback without C++ heap allocation, show realistic + native footprint
                val effectiveAppRam = if (snap.brainLoadedInRam && !LlamaBridge.isNativeLibAvailable) {
                    pssMb + 265
                } else {
                    pssMb
                }
                JarvisStateBus.updateState {
                    it.copy(
                        appRamMb = effectiveAppRam,
                        deviceAvailableRamMb = availMb,
                        deviceTotalRamMb = totalMb
                    )
                }
                delay(1500L)
            }
        }
    }

    private fun stripWakePrefix(utterance: String, wakeLine: String): String {
        val lower = utterance.lowercase(Locale.US)
        val idx = lower.indexOf(wakeLine.lowercase(Locale.US))
        return if (idx >= 0) {
            utterance.substring(idx + wakeLine.length).trim()
        } else {
            utterance.trim()
        }
    }

    private fun extractTrailingCommand(utterance: String, wakeLine: String): String {
        return stripWakePrefix(utterance, wakeLine)
    }

    private fun startAsForegroundService() {
        createNotificationChannel()
        val notification = buildStatusNotification()
        try {
            val hasMicPermission = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && hasMicPermission) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (_: Throwable) {
            try {
                startForeground(NOTIFICATION_ID, notification)
            } catch (_: Throwable) {
            }
        }
    }

    private fun updateForegroundNotification() {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            nm?.notify(NOTIFICATION_ID, buildStatusNotification())
        } catch (_: Throwable) {
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            nm?.createNotificationChannel(channel)
        }
    }

    private fun buildStatusNotification(): Notification {
        val snap = JarvisStateBus.snapshot.value
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpen = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = when (snap.state) {
            JarvisOrchestratorState.SLEEPING ->
                "JARVIS • SLEEPING (RAM: ${snap.appRamMb} MB)"
            JarvisOrchestratorState.WAKING_BRAIN ->
                "JARVIS • WAKING GGUF BRAIN..."
            JarvisOrchestratorState.ONLINE ->
                "JARVIS • ONLINE (Auto-sleep in ${snap.remainingWakeSeconds}s)"
            JarvisOrchestratorState.EXECUTING ->
                "JARVIS • EXECUTING COMMAND..."
        }

        val body = when (snap.state) {
            JarvisOrchestratorState.SLEEPING ->
                "Ear listening for \"${snap.wakeLine}\" • Brain 0 MB Unloaded"
            else ->
                snap.lastActionFeedback
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pendingOpen)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    override fun onDestroy() {
        inactivityTimerJob?.cancel()
        telemetryLoopJob?.cancel()
        stopVoskStreamInternal()
        LlamaBridge.freeModel()
        try {
            toneGenerator?.release()
        } catch (_: Throwable) {
        }
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Throwable) {
        }
        JarvisStateBus.updateState { it.copy(serviceRunning = false, voskListening = false) }
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "jarvis_offline_ear_channel"
        private const val NOTIFICATION_ID = 1042

        const val ACTION_START_OR_SYNC = "com.example.service.action.START_OR_SYNC"
        const val ACTION_MANUAL_WAKE = "com.example.service.action.MANUAL_WAKE"
        const val ACTION_MANUAL_SLEEP = "com.example.service.action.MANUAL_SLEEP"
        const val ACTION_RELOAD_CONFIG = "com.example.service.action.RELOAD_CONFIG"
        const val ACTION_RELOAD_VOSK = "com.example.service.action.RELOAD_VOSK"
        const val ACTION_EXECUTE_TEXT_COMMAND = "com.example.service.action.EXECUTE_TEXT_COMMAND"
        const val EXTRA_COMMAND_TEXT = "extra_command_text"

        fun sendAction(context: Context, action: String, commandText: String? = null) {
            val appContext = context.applicationContext
            val intent = Intent(appContext, JarvisService::class.java).apply {
                this.action = action
                if (commandText != null) {
                    putExtra(EXTRA_COMMAND_TEXT, commandText)
                }
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    appContext.startForegroundService(intent)
                } else {
                    appContext.startService(intent)
                }
            } catch (_: Throwable) {
                try {
                    appContext.startService(intent)
                } catch (_: Throwable) {
                }
            }
        }
    }
}
