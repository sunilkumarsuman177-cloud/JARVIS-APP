package com.example.engine

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

object VoskModelManager {
    const val VOSK_MODEL_DIR_NAME = "vosk-model"
    const val VOSK_DOWNLOAD_URL =
        "https://alphacephei.com/vosk/models/vosk-model-small-en-in-0.4.zip"

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()

    fun getModelDir(context: Context): File {
        return File(context.applicationContext.filesDir, VOSK_MODEL_DIR_NAME)
    }

    /**
     * Checks if `File(filesDir, "vosk-model")` exists and has valid Vosk acoustic model files.
     */
    fun isVoskModelInstalled(context: Context): Boolean {
        val dir = getModelDir(context)
        if (!dir.exists() || !dir.isDirectory) return false
        val hasAm = File(dir, "am").exists() || File(dir, "final.mdl").exists()
        val hasConf = File(dir, "conf").exists() || File(dir, "mfcc.conf").exists()
        val children = dir.listFiles()
        return hasAm || hasConf || (children != null && children.size >= 2)
    }

    /**
     * Downloads `vosk-model-small-en-in-0.4.zip` (36 MB) with live progress callback
     * and unzips directly into `filesDir/vosk-model` for 100% offline use forever after.
     */
    suspend fun downloadAndInstallVoskModel(
        context: Context,
        onProgress: (percent: Int, status: String) -> Unit
    ): Result<File> = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        val tempZip = File(appContext.cacheDir, "vosk-model-download.zip")
        try {
            onProgress(1, "Connecting to alphacephei.com (36 MB Voice Pack)...")
            val request = Request.Builder()
                .url(VOSK_DOWNLOAD_URL)
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext Result.failure(
                        IllegalStateException("HTTP ${response.code}: Failed to download Vosk pack")
                    )
                }
                val body = response.body
                    ?: return@withContext Result.failure(IllegalStateException("Empty response body"))

                val contentLength = body.contentLength().takeIf { it > 0 } ?: (36L * 1024L * 1024L)
                var totalRead = 0L

                body.byteStream().use { input ->
                    FileOutputStream(tempZip).use { output ->
                        val buffer = ByteArray(32 * 1024)
                        var read: Int
                        var lastReportedPct = -1
                        while (input.read(buffer).also { read = it } != -1) {
                            output.write(buffer, 0, read)
                            totalRead += read
                            val pct = ((totalRead * 85L) / contentLength).toInt().coerceIn(1, 85)
                            if (pct != lastReportedPct) {
                                lastReportedPct = pct
                                val downloadedMb = totalRead / (1024 * 1024)
                                val totalMb = contentLength / (1024 * 1024)
                                onProgress(pct, "Downloading Voice Pack: $downloadedMb / $totalMb MB ($pct%)")
                            }
                        }
                        output.flush()
                    }
                }
            }

            onProgress(88, "Extracting offline acoustic model into filesDir/vosk-model...")
            val modelDir = getModelDir(appContext)
            FileInputStream(tempZip).use { fis ->
                extractZipIntoTargetDir(fis, modelDir) { status ->
                    onProgress(94, status)
                }
            }
            tempZip.delete()
            onProgress(100, "Vosk Offline Ear Ready (filesDir/vosk-model)")
            Result.success(modelDir)
        } catch (e: Exception) {
            tempZip.delete()
            Result.failure(e)
        }
    }

    /**
     * Allows picking a local `vosk-model-*.zip` from device storage completely offline.
     */
    suspend fun importLocalVoskZip(
        context: Context,
        uri: Uri,
        onProgress: (percent: Int, status: String) -> Unit
    ): Result<File> = withContext(Dispatchers.IO) {
        val appContext = context.applicationContext
        try {
            onProgress(15, "Reading local Vosk .zip archive...")
            val modelDir = getModelDir(appContext)
            val inputStream = appContext.contentResolver.openInputStream(uri)
                ?: return@withContext Result.failure(IllegalStateException("Unable to open selected .zip file"))

            inputStream.use { stream ->
                extractZipIntoTargetDir(stream, modelDir) { status ->
                    onProgress(75, status)
                }
            }
            onProgress(100, "Local Vosk Voice Pack installed into filesDir/vosk-model!")
            Result.success(modelDir)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun extractZipIntoTargetDir(
        rawStream: InputStream,
        targetDir: File,
        onEntryStatus: (String) -> Unit
    ) {
        val stagingDir = File(targetDir.parentFile, "vosk-model-staging")
        if (stagingDir.exists()) stagingDir.deleteRecursively()
        stagingDir.mkdirs()

        ZipInputStream(BufferedInputStream(rawStream)).use { zis ->
            var entry = zis.nextEntry
            var count = 0
            while (entry != null) {
                val safeName = entry.name.removePrefix("/").trim()
                if (safeName.isNotEmpty() && !safeName.contains("..")) {
                    val outFile = File(stagingDir, safeName)
                    if (entry.isDirectory) {
                        outFile.mkdirs()
                    } else {
                        outFile.parentFile?.mkdirs()
                        FileOutputStream(outFile).use { fos ->
                            val buf = ByteArray(16 * 1024)
                            var len: Int
                            while (zis.read(buf).also { len = it } > 0) {
                                fos.write(buf, 0, len)
                            }
                        }
                        count++
                        if (count % 5 == 0) {
                            onEntryStatus("Unpacking acoustic files ($count extracted)...")
                        }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }

        // If the zip contained a single root folder (e.g., vosk-model-small-en-in-0.4/), flatten it
        val topChildren = stagingDir.listFiles() ?: emptyArray()
        val effectiveRoot = if (topChildren.size == 1 && topChildren[0].isDirectory) {
            topChildren[0]
        } else {
            stagingDir
        }

        if (targetDir.exists()) {
            targetDir.deleteRecursively()
        }
        targetDir.mkdirs()

        effectiveRoot.copyRecursively(targetDir, overwrite = true)
        stagingDir.deleteRecursively()
    }
}
