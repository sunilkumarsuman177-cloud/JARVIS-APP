package com.example.engine

import android.Manifest
import android.app.NotificationManager
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.example.service.JarvisAccessibilityService
import com.example.service.JarvisStateBus
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale

data class OrchestrationOutcome(
    val action: String,
    val success: Boolean,
    val summary: String,
    val spokenFeedback: String
)

class PhoneOrchestrator(private val context: Context) {
    private val appContext = context.applicationContext

    fun executeJsonCommand(
        rawJson: String,
        onSpeak: (String) -> Unit
    ): OrchestrationOutcome {
        return try {
            val json = JSONObject(rawJson)
            val action = json.optString("action", "").trim().lowercase(Locale.US)

            val outcome = when (action) {
                "wifi" -> handleWifi(json.optString("state", "on"))
                "bluetooth" -> handleBluetooth(json.optString("state", "on"))
                "flashlight" -> handleFlashlight(json.optString("state", "on"))
                "dnd" -> handleDnd(json.optString("state", "on"))
                "volume" -> handleVolume(json.optInt("level", 50))
                "open_app" -> handleOpenApp(json.optString("query", ""))
                "call" -> handleCall(json.optString("name", ""))
                "alarm" -> handleAlarm(json.optInt("minutes", 30))
                "ui_click" -> handleUiClick(json.optString("text", ""))
                "nav" -> handleNav(json.optString("target", "home"))
                "speak" -> {
                    val reply = json.optString("text", "Online and ready.")
                    OrchestrationOutcome(
                        action = "speak",
                        success = true,
                        summary = "Spoke: \"$reply\"",
                        spokenFeedback = reply
                    )
                }
                else -> OrchestrationOutcome(
                    action = action.ifEmpty { "unknown" },
                    success = false,
                    summary = "Unrecognized JSON action: $rawJson",
                    spokenFeedback = "Unrecognized action."
                )
            }

            if (outcome.spokenFeedback.isNotBlank()) {
                onSpeak(outcome.spokenFeedback)
            }
            JarvisStateBus.appendLog("EXEC", "${outcome.summary} [${if (outcome.success) "OK" else "INFO"}]")
            outcome
        } catch (e: Exception) {
            val msg = "JSON parse/exec error: ${e.localizedMessage ?: "invalid JSON"}"
            JarvisStateBus.appendLog("ERROR", msg)
            OrchestrationOutcome("error", false, msg, "Could not execute that action.")
        }
    }

    @Suppress("DEPRECATION")
    private fun handleWifi(state: String): OrchestrationOutcome {
        val enable = state.equals("on", ignoreCase = true)
        return try {
            val wifiManager = appContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q && wifiManager != null) {
                wifiManager.isWifiEnabled = enable
                OrchestrationOutcome(
                    action = "wifi",
                    success = true,
                    summary = "Wi-Fi turned ${if (enable) "ON" else "OFF"}",
                    spokenFeedback = "Wi-Fi ${if (enable) "enabled" else "disabled"}."
                )
            } else {
                val panelIntent = Intent(Settings.Panel.ACTION_WIFI).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                appContext.startActivity(panelIntent)
                OrchestrationOutcome(
                    action = "wifi",
                    success = true,
                    summary = "Opened Wi-Fi Quick Panel (${if (enable) "ON" else "OFF"})",
                    spokenFeedback = "Opening Wi-Fi controls."
                )
            }
        } catch (_: Exception) {
            val settingsIntent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            appContext.startActivity(settingsIntent)
            OrchestrationOutcome("wifi", true, "Opened Wi-Fi Settings", "Opening Wi-Fi settings.")
        }
    }

    @Suppress("DEPRECATION", "MissingPermission")
    private fun handleBluetooth(state: String): OrchestrationOutcome {
        val enable = state.equals("on", ignoreCase = true)
        return try {
            val btManager = appContext.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
            val adapter: BluetoothAdapter? = btManager?.adapter
            val hasBtPerm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                ContextCompat.checkSelfPermission(
                    appContext,
                    Manifest.permission.BLUETOOTH_CONNECT
                ) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }

            if (adapter != null && hasBtPerm && Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                val changed = if (enable) adapter.enable() else adapter.disable()
                if (changed) {
                    return OrchestrationOutcome(
                        action = "bluetooth",
                        success = true,
                        summary = "Bluetooth turned ${if (enable) "ON" else "OFF"}",
                        spokenFeedback = "Bluetooth ${if (enable) "enabled" else "disabled"}."
                    )
                }
            }

            val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            appContext.startActivity(intent)
            OrchestrationOutcome(
                action = "bluetooth",
                success = true,
                summary = "Opened Bluetooth Settings (${if (enable) "ON" else "OFF"})",
                spokenFeedback = "Opening Bluetooth settings."
            )
        } catch (_: Exception) {
            OrchestrationOutcome("bluetooth", false, "Bluetooth toggle unavailable", "Bluetooth unavailable.")
        }
    }

    private fun handleFlashlight(state: String): OrchestrationOutcome {
        val enable = state.equals("on", ignoreCase = true)
        return try {
            val cameraManager = appContext.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
                ?: return OrchestrationOutcome("flashlight", false, "CameraManager unavailable", "Torch unavailable.")

            val torchCameraId = cameraManager.cameraIdList.firstOrNull { id ->
                val chars = cameraManager.getCameraCharacteristics(id)
                chars.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: cameraManager.cameraIdList.firstOrNull()

            if (torchCameraId != null) {
                cameraManager.setTorchMode(torchCameraId, enable)
                OrchestrationOutcome(
                    action = "flashlight",
                    success = true,
                    summary = "Rear Camera Torch turned ${if (enable) "ON" else "OFF"}",
                    spokenFeedback = "Flashlight ${if (enable) "on" else "off"}."
                )
            } else {
                OrchestrationOutcome("flashlight", false, "No flash unit detected", "No flashlight found.")
            }
        } catch (e: Exception) {
            OrchestrationOutcome(
                action = "flashlight",
                success = false,
                summary = "Torch error: ${e.localizedMessage ?: "hardware unavailable"}",
                spokenFeedback = "Flashlight hardware unavailable."
            )
        }
    }

    private fun handleDnd(state: String): OrchestrationOutcome {
        val enable = state.equals("on", ignoreCase = true)
        return try {
            val notificationManager =
                appContext.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

            if (notificationManager != null && notificationManager.isNotificationPolicyAccessGranted) {
                notificationManager.setInterruptionFilter(
                    if (enable) {
                        NotificationManager.INTERRUPTION_FILTER_NONE
                    } else {
                        NotificationManager.INTERRUPTION_FILTER_ALL
                    }
                )
                audioManager?.ringerMode = if (enable) {
                    AudioManager.RINGER_MODE_SILENT
                } else {
                    AudioManager.RINGER_MODE_NORMAL
                }
                OrchestrationOutcome(
                    action = "dnd",
                    success = true,
                    summary = "Do Not Disturb turned ${if (enable) "ON" else "OFF"}",
                    spokenFeedback = "Do not disturb ${if (enable) "activated" else "deactivated"}."
                )
            } else {
                // Fallback to Vibrate/Normal ringer mode or open DND policy settings
                audioManager?.ringerMode = if (enable) {
                    AudioManager.RINGER_MODE_VIBRATE
                } else {
                    AudioManager.RINGER_MODE_NORMAL
                }
                OrchestrationOutcome(
                    action = "dnd",
                    success = true,
                    summary = "Ringer switched to ${if (enable) "VIBRATE / SILENT" else "NORMAL"}",
                    spokenFeedback = "Ringer set to ${if (enable) "vibrate" else "normal"}."
                )
            }
        } catch (_: Exception) {
            val intent = Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            appContext.startActivity(intent)
            OrchestrationOutcome("dnd", true, "Opened DND Policy Settings", "Grant Do Not Disturb access.")
        }
    }

    private fun handleVolume(level: Int): OrchestrationOutcome {
        val clamped = level.coerceIn(0, 100)
        return try {
            val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                ?: return OrchestrationOutcome("volume", false, "AudioManager unavailable", "")

            val maxMedia = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            val targetMedia = ((clamped / 100.0) * maxMedia).toInt().coerceIn(0, maxMedia)
            audioManager.setStreamVolume(
                AudioManager.STREAM_MUSIC,
                targetMedia,
                AudioManager.FLAG_SHOW_UI
            )

            OrchestrationOutcome(
                action = "volume",
                success = true,
                summary = "Media volume set to $clamped% ($targetMedia/$maxMedia)",
                spokenFeedback = "Volume set to $clamped percent."
            )
        } catch (e: Exception) {
            OrchestrationOutcome("volume", false, "Volume error: ${e.message}", "Unable to change volume.")
        }
    }

    private fun handleOpenApp(query: String): OrchestrationOutcome {
        val cleanQuery = query.trim().lowercase(Locale.US)
        if (cleanQuery.isEmpty()) {
            return OrchestrationOutcome("open_app", false, "Empty app query", "Which app should I open?")
        }

        // Fast built-in system intents for universal system utilities
        when (cleanQuery) {
            "settings", "setting" -> {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                appContext.startActivity(intent)
                return OrchestrationOutcome("open_app", true, "Launched Android Settings", "Opening Settings.")
            }
        }

        return try {
            val pm = appContext.packageManager
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolveInfos = pm.queryIntentActivities(mainIntent, 0)

            var bestPackage: String? = null
            var bestLabel: String? = null
            var bestScore = 0

            for (info in resolveInfos) {
                val pkg = info.activityInfo.packageName.lowercase(Locale.US)
                val label = info.loadLabel(pm).toString().lowercase(Locale.US)

                val score = when {
                    label == cleanQuery -> 100
                    label.startsWith(cleanQuery) -> 85
                    label.contains(cleanQuery) -> 70
                    pkg.contains(cleanQuery) -> 55
                    else -> 0
                }
                if (score > bestScore) {
                    bestScore = score
                    bestPackage = info.activityInfo.packageName
                    bestLabel = info.loadLabel(pm).toString()
                }
            }

            if (bestPackage != null) {
                val launchIntent = pm.getLaunchIntentForPackage(bestPackage)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    appContext.startActivity(launchIntent)
                    return OrchestrationOutcome(
                        action = "open_app",
                        success = true,
                        summary = "Launched $bestLabel ($bestPackage)",
                        spokenFeedback = "Opening $bestLabel."
                    )
                }
            }

            // Common system fallbacks (Camera, Calculator, YouTube)
            if (cleanQuery.contains("camera")) {
                val camIntent = Intent("android.media.action.IMAGE_CAPTURE").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                appContext.startActivity(camIntent)
                return OrchestrationOutcome("open_app", true, "Launched Camera", "Opening Camera.")
            }

            OrchestrationOutcome(
                action = "open_app",
                success = false,
                summary = "App '$query' not installed on device",
                spokenFeedback = "$query is not installed."
            )
        } catch (e: Exception) {
            OrchestrationOutcome("open_app", false, "Failed to launch '$query'", "Could not open $query.")
        }
    }

    private fun handleCall(nameOrNumber: String): OrchestrationOutcome {
        val target = nameOrNumber.trim()
        if (target.isEmpty()) {
            return OrchestrationOutcome("call", false, "Missing contact name", "Who should I call?")
        }

        val resolvedNumber = resolveContactPhoneNumber(target) ?: target.filter { it.isDigit() || it == '+' }
        val hasDirectCallPerm = ContextCompat.checkSelfPermission(
            appContext,
            Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED

        return try {
            val uri = Uri.parse("tel:${Uri.encode(resolvedNumber.ifEmpty { target })}")
            val intent = Intent(if (hasDirectCallPerm && resolvedNumber.isNotEmpty()) Intent.ACTION_CALL else Intent.ACTION_DIAL, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            appContext.startActivity(intent)
            OrchestrationOutcome(
                action = "call",
                success = true,
                summary = "${if (hasDirectCallPerm) "Calling" else "Dialing"} $target (${resolvedNumber.ifEmpty { "dialer" }})",
                spokenFeedback = "Calling $target."
            )
        } catch (e: Exception) {
            OrchestrationOutcome("call", false, "Could not place call to $target", "Unable to place call.")
        }
    }

    private fun resolveContactPhoneNumber(contactQuery: String): String? {
        if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.READ_CONTACTS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            return null
        }
        return try {
            val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            val projection = arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            )
            val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
            val selectionArgs = arrayOf("%$contactQuery%")

            appContext.contentResolver.query(uri, projection, selection, selectionArgs, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val numberIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    if (numberIdx >= 0) {
                        return cursor.getString(numberIdx)
                    }
                }
            }
            null
        } catch (_: Exception) {
            null
        }
    }

    private fun handleAlarm(minutesFromNow: Int): OrchestrationOutcome {
        val validMinutes = minutesFromNow.coerceAtLeast(1)
        return try {
            val calendar = Calendar.getInstance().apply {
                add(Calendar.MINUTE, validMinutes)
            }
            val hour = calendar.get(Calendar.HOUR_OF_DAY)
            val minute = calendar.get(Calendar.MINUTE)

            val alarmIntent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, "JARVIS Alarm ($validMinutes min)")
                putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            appContext.startActivity(alarmIntent)
            val formattedTime = String.format(Locale.US, "%02d:%02d", hour, minute)
            OrchestrationOutcome(
                action = "alarm",
                success = true,
                summary = "System alarm set for $formattedTime (+$validMinutes min)",
                spokenFeedback = "Alarm set for $validMinutes minutes from now."
            )
        } catch (_: Exception) {
            OrchestrationOutcome("alarm", false, "No Clock app handled SET_ALARM intent", "Could not set alarm.")
        }
    }

    private fun handleUiClick(buttonText: String): OrchestrationOutcome {
        val a11y = JarvisAccessibilityService.instance
        if (a11y == null) {
            return OrchestrationOutcome(
                action = "ui_click",
                success = false,
                summary = "Accessibility Service not enabled for clicking '$buttonText'",
                spokenFeedback = "Enable JARVIS Accessibility Service first."
            )
        }
        val clicked = a11y.clickByText(buttonText)
        return if (clicked) {
            OrchestrationOutcome(
                action = "ui_click",
                success = true,
                summary = "Clicked screen element matching \"$buttonText\"",
                spokenFeedback = "Clicked $buttonText."
            )
        } else {
            OrchestrationOutcome(
                action = "ui_click",
                success = false,
                summary = "No screen element matched \"$buttonText\"",
                spokenFeedback = "Could not find $buttonText on screen."
            )
        }
    }

    private fun handleNav(target: String): OrchestrationOutcome {
        val a11y = JarvisAccessibilityService.instance
        if (a11y == null) {
            return OrchestrationOutcome(
                action = "nav",
                success = false,
                summary = "Accessibility Service not enabled for nav '$target'",
                spokenFeedback = "Enable JARVIS Accessibility Service first."
            )
        }
        val ok = a11y.executeNavigation(target)
        return OrchestrationOutcome(
            action = "nav",
            success = ok,
            summary = "Executed global navigation: $target",
            spokenFeedback = if (ok) "" else "Navigation failed."
        )
    }
}
