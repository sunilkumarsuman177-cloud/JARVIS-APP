cmake_minimum_required(VERSION 3.22.1)
project("jarvis-native" LANGUAGES C CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

# Optimize for both 32-bit (armeabi-v7a) and 64-bit (arm64-v8a) on Samsung Galaxy A10 (Exynos 7884)
if (ANDROID_ABI STREQUAL "arm64-v8a")
    add_compile_options(-O3 -DNDEBUG -ffast-math -funroll-loops)
elseif (ANDROID_ABI STREQUAL "armeabi-v7a")
    add_compile_options(-O3 -DNDEBUG -ffast-math -funroll-loops -mfpu=neon)
endif()

set(LLAMA_DIR "${CMAKE_CURRENT_SOURCE_DIR}/llama.cpp")

add_library(jarvis-native SHARED
    native-lib.cpp
)

find_library(log-lib log)
find_library(android-lib android)

if (EXISTS "${LLAMA_DIR}/CMakeLists.txt")
    message(STATUS "[JARVIS-NDK] Found llama.cpp at ${LLAMA_DIR} — compiling native GGUF engine")

    set(BUILD_SHARED_LIBS OFF CACHE BOOL "Build static llama/ggml libs" FORCE)
    set(LLAMA_BUILD_TESTS OFF CACHE BOOL "Disable llama tests" FORCE)
    set(LLAMA_BUILD_EXAMPLES OFF CACHE BOOL "Disable llama examples" FORCE)
    set(LLAMA_BUILD_SERVER OFF CACHE BOOL "Disable llama server" FORCE)
    set(LLAMA_CURL OFF CACHE BOOL "Disable CURL for 100% offline build" FORCE)
    set(GGML_OPENMP OFF CACHE BOOL "Disable OpenMP on Android NDK" FORCE)
    set(GGML_LLAMAFILE OFF CACHE BOOL "Disable llamafile on Android" FORCE)

    add_subdirectory("${LLAMA_DIR}" build-llama EXCLUDE_FROM_ALL)

    target_compile_definitions(jarvis-native PRIVATE HAVE_LLAMA_CPP=1)

    target_include_directories(jarvis-native PRIVATE
        "${LLAMA_DIR}"
        "${LLAMA_DIR}/include"
        "${LLAMA_DIR}/ggml/include"
        "${LLAMA_DIR}/common"
    )

    if (TARGET ggml)
        target_link_libraries(jarvis-native PRIVATE llama ggml ${log-lib} ${android-lib})
    else()
        target_link_libraries(jarvis-native PRIVATE llama ${log-lib} ${android-lib})
    endif()
else()
    message(WARNING "[JARVIS-NDK] llama.cpp/CMakeLists.txt not yet uploaded. Building resilient JNI fallback bridge.")
    target_compile_definitions(jarvis-native PRIVATE HAVE_LLAMA_CPP=0)
    target_link_libraries(jarvis-native PRIVATE ${log-lib} ${android-lib})
endif()
