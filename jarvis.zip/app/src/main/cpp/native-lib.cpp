#include <jni.h>
#include <string>
#include <vector>
#include <mutex>
#include <algorithm>
#include <cctype>
#include <fstream>
#include <sstream>
#include <cstring>
#include <android/log.h>

#define LOG_TAG "JARVIS_NDK"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

#if HAVE_LLAMA_CPP
#include "llama.h"
#endif

namespace {

std::mutex g_engine_mutex;
std::string g_loaded_model_path;
bool g_virtual_model_loaded = false;

#if HAVE_LLAMA_CPP
llama_model* g_model = nullptr;
llama_context* g_ctx = nullptr;
llama_sampler* g_sampler = nullptr;
#endif

// Strict ChatML system prompt forcing SmolLM2-360M-Instruct-Q4_K_M.gguf to emit ONLY compact JSON
const char* kJarvisSystemPrompt =
    "<|im_start|>system\n"
    "You are JARVIS, an offline Android phone orchestrator by Prince Priyadarshi. "
    "Output ONLY a single compact JSON object matching one of these schemas and nothing else:\n"
    "{\"action\":\"wifi\",\"state\":\"on|off\"}\n"
    "{\"action\":\"bluetooth\",\"state\":\"on|off\"}\n"
    "{\"action\":\"flashlight\",\"state\":\"on|off\"}\n"
    "{\"action\":\"dnd\",\"state\":\"on|off\"}\n"
    "{\"action\":\"volume\",\"level\":50}\n"
    "{\"action\":\"open_app\",\"query\":\"whatsapp|youtube|camera|calculator|settings\"}\n"
    "{\"action\":\"call\",\"name\":\"Mom\"}\n"
    "{\"action\":\"alarm\",\"minutes\":30}\n"
    "{\"action\":\"ui_click\",\"text\":\"Send\"}\n"
    "{\"action\":\"nav\",\"target\":\"home|back|recents|notifications|scroll_down|scroll_up\"}\n"
    "{\"action\":\"speak\",\"text\":\"Concise reply under 15 words\"}\n"
    "<|im_end|>\n";

std::string toLowerAscii(const std::string& input) {
    std::string out = input;
    std::transform(out.begin(), out.end(), out.begin(),
                   [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return out;
}

std::string escapeJsonString(const std::string& input) {
    std::ostringstream oss;
    for (char c : input) {
        switch (c) {
            case '"': oss << "\\\""; break;
            case '\\': oss << "\\\\"; break;
            case '\n': oss << " "; break;
            case '\r': break;
            case '\t': oss << " "; break;
            default: oss << c; break;
        }
    }
    return oss.str();
}

int extractFirstNumber(const std::string& text, int fallback) {
    std::string digits;
    for (char c : text) {
        if (std::isdigit(static_cast<unsigned char>(c))) {
            digits.push_back(c);
        } else if (!digits.empty()) {
            break;
        }
    }
    if (digits.empty()) return fallback;
    try {
        return std::stoi(digits);
    } catch (...) {
        return fallback;
    }
}

// Extracts the first balanced {...} JSON object from raw model output
std::string extractJsonObject(const std::string& raw) {
    size_t start = raw.find('{');
    if (start == std::string::npos) return "";
    int depth = 0;
    bool inQuotes = false;
    bool escaped = false;
    for (size_t i = start; i < raw.size(); ++i) {
        char c = raw[i];
        if (escaped) {
            escaped = false;
            continue;
        }
        if (c == '\\') {
            escaped = true;
            continue;
        }
        if (c == '"') {
            inQuotes = !inQuotes;
            continue;
        }
        if (!inQuotes) {
            if (c == '{') depth++;
            else if (c == '}') {
                depth--;
                if (depth == 0) {
                    return raw.substr(start, i - start + 1);
                }
            }
        }
    }
    return "";
}

// Deterministic fallback parser in C++ when GGUF output is malformed or llama.cpp is not yet linked
std::string fallbackRuleBasedJson(const std::string& userText) {
    std::string lower = toLowerAscii(userText);
    bool turnOff = (lower.find("off") != std::string::npos ||
                    lower.find("disable") != std::string::npos ||
                    lower.find("stop") != std::string::npos ||
                    lower.find("close") != std::string::npos);

    if (lower.find("wifi") != std::string::npos || lower.find("wi-fi") != std::string::npos) {
        return std::string("{\"action\":\"wifi\",\"state\":\"") + (turnOff ? "off" : "on") + "\"}";
    }
    if (lower.find("bluetooth") != std::string::npos) {
        return std::string("{\"action\":\"bluetooth\",\"state\":\"") + (turnOff ? "off" : "on") + "\"}";
    }
    if (lower.find("flash") != std::string::npos || lower.find("torch") != std::string::npos ||
        lower.find("light") != std::string::npos) {
        return std::string("{\"action\":\"flashlight\",\"state\":\"") + (turnOff ? "off" : "on") + "\"}";
    }
    if (lower.find("dnd") != std::string::npos || lower.find("do not disturb") != std::string::npos ||
        lower.find("silent") != std::string::npos || lower.find("mute") != std::string::npos) {
        return std::string("{\"action\":\"dnd\",\"state\":\"") + (turnOff ? "off" : "on") + "\"}";
    }
    if (lower.find("volume") != std::string::npos || lower.find("louder") != std::string::npos ||
        lower.find("quieter") != std::string::npos) {
        int lvl = extractFirstNumber(lower, -1);
        if (lvl < 0) {
            if (lower.find("max") != std::string::npos || lower.find("full") != std::string::npos) lvl = 100;
            else if (lower.find("louder") != std::string::npos || lower.find("up") != std::string::npos) lvl = 80;
            else if (lower.find("quieter") != std::string::npos || lower.find("down") != std::string::npos) lvl = 30;
            else lvl = 50;
        }
        lvl = std::max(0, std::min(100, lvl));
        return "{\"action\":\"volume\",\"level\":" + std::to_string(lvl) + "}";
    }
    if (lower.find("alarm") != std::string::npos || lower.find("timer") != std::string::npos ||
        lower.find("wake me") != std::string::npos) {
        int mins = extractFirstNumber(lower, 30);
        if (lower.find("hour") != std::string::npos && mins <= 12) {
            mins *= 60;
        }
        return "{\"action\":\"alarm\",\"minutes\":" + std::to_string(std::max(1, mins)) + "}";
    }
    if (lower.find("call ") != std::string::npos || lower.find("dial ") != std::string::npos) {
        size_t pos = lower.find("call ");
        size_t len = 5;
        if (pos == std::string::npos) {
            pos = lower.find("dial ");
            len = 5;
        }
        std::string target = userText.substr(pos + len);
        return "{\"action\":\"call\",\"name\":\"" + escapeJsonString(target) + "\"}";
    }
    if (lower.find("open ") != std::string::npos || lower.find("launch ") != std::string::npos) {
        size_t pos = lower.find("open ");
        size_t len = 5;
        if (pos == std::string::npos) {
            pos = lower.find("launch ");
            len = 7;
        }
        std::string appQuery = lower.substr(pos + len);
        return "{\"action\":\"open_app\",\"query\":\"" + escapeJsonString(appQuery) + "\"}";
    }
    if (lower.find("click ") != std::string::npos || lower.find("tap ") != std::string::npos ||
        lower.find("press ") != std::string::npos) {
        size_t pos = lower.find("click ");
        size_t len = 6;
        if (pos == std::string::npos) {
            pos = lower.find("tap ");
            len = 4;
        }
        if (pos == std::string::npos) {
            pos = lower.find("press ");
            len = 6;
        }
        std::string btnText = userText.substr(pos + len);
        return "{\"action\":\"ui_click\",\"text\":\"" + escapeJsonString(btnText) + "\"}";
    }
    if (lower.find("scroll down") != std::string::npos) {
        return "{\"action\":\"nav\",\"target\":\"scroll_down\"}";
    }
    if (lower.find("scroll up") != std::string::npos) {
        return "{\"action\":\"nav\",\"target\":\"scroll_up\"}";
    }
    if (lower.find("go home") != std::string::npos || lower == "home") {
        return "{\"action\":\"nav\",\"target\":\"home\"}";
    }
    if (lower.find("go back") != std::string::npos || lower == "back") {
        return "{\"action\":\"nav\",\"target\":\"back\"}";
    }
    if (lower.find("recent") != std::string::npos) {
        return "{\"action\":\"nav\",\"target\":\"recents\"}";
    }
    if (lower.find("notification") != std::string::npos) {
        return "{\"action\":\"nav\",\"target\":\"notifications\"}";
    }
    return "{\"action\":\"speak\",\"text\":\"At your service. Command processed offline.\"}";
}

bool verifyGgufHeader(const std::string& path) {
    std::ifstream file(path, std::ios::binary);
    if (!file.is_open()) return false;
    char magic[4] = {0};
    file.read(magic, 4);
    return (file.gcount() == 4 && magic[0] == 'G' && magic[1] == 'G' && magic[2] == 'U' && magic[3] == 'F');
}

} // namespace

extern "C"
JNIEXPORT jboolean JNICALL
Java_com_example_engine_LlamaBridge_nativeLoadModel(
        JNIEnv* env,
        jobject /* thiz */,
        jstring modelPath) {
    std::lock_guard<std::mutex> lock(g_engine_mutex);

    if (modelPath == nullptr) {
        LOGE("nativeLoadModel received null modelPath");
        return JNI_FALSE;
    }

    const char* pathChars = env->GetStringUTFChars(modelPath, nullptr);
    std::string pathStr(pathChars ? pathChars : "");
    if (pathChars) {
        env->ReleaseStringUTFChars(modelPath, pathChars);
    }

#if HAVE_LLAMA_CPP
    if (g_model != nullptr && g_ctx != nullptr && g_loaded_model_path == pathStr) {
        LOGI("GGUF model already loaded in RAM: %s", pathStr.c_str());
        return JNI_TRUE;
    }

    // Free any previous instance first
    if (g_sampler != nullptr) {
        llama_sampler_free(g_sampler);
        g_sampler = nullptr;
    }
    if (g_ctx != nullptr) {
        llama_free(g_ctx);
        g_ctx = nullptr;
    }
    if (g_model != nullptr) {
        llama_model_free(g_model);
        g_model = nullptr;
    }

    llama_backend_init();

    llama_model_params model_params = llama_model_default_params();
    model_params.n_gpu_layers = 0; // CPU-only for Exynos 7884
    model_params.use_mmap = true;
    model_params.use_mlock = false;

    LOGI("Loading GGUF model from %s (2 GB RAM tuned)...", pathStr.c_str());
    g_model = llama_model_load_from_file(pathStr.c_str(), model_params);
    if (g_model == nullptr) {
        LOGE("Failed to load GGUF model from %s", pathStr.c_str());
        return JNI_FALSE;
    }

    llama_context_params ctx_params = llama_context_default_params();
    ctx_params.n_ctx = 512;          // Strictly 512 context window for < 300 MB footprint
    ctx_params.n_batch = 128;        // 128 batch size tuned for Galaxy A10
    ctx_params.n_ubatch = 128;
    ctx_params.n_threads = 4;        // 4 threads (2x Cortex-A73 + 2x Cortex-A53)
    ctx_params.n_threads_batch = 4;

    g_ctx = llama_init_from_model(g_model, ctx_params);
    if (g_ctx == nullptr) {
        LOGE("Failed to create llama_context");
        llama_model_free(g_model);
        g_model = nullptr;
        return JNI_FALSE;
    }

    llama_sampler_chain_params sparams = llama_sampler_chain_default_params();
    g_sampler = llama_sampler_chain_init(sparams);
    llama_sampler_chain_add(g_sampler, llama_sampler_init_temp(0.10f));
    llama_sampler_chain_add(g_sampler, llama_sampler_init_dist(42));

    g_loaded_model_path = pathStr;
    g_virtual_model_loaded = true;
    LOGI("SmolLM2 GGUF Brain online (n_ctx=512, n_threads=4, n_batch=128)");
    return JNI_TRUE;
#else
    if (!pathStr.empty() && verifyGgufHeader(pathStr)) {
        LOGI("Verified valid GGUF magic header at %s (Fallback C++ Engine active until llama.cpp is uploaded)", pathStr.c_str());
    } else {
        LOGW("Using C++ deterministic intent engine (path=%s)", pathStr.c_str());
    }
    g_loaded_model_path = pathStr;
    g_virtual_model_loaded = true;
    return JNI_TRUE;
#endif
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_example_engine_LlamaBridge_nativeInfer(
        JNIEnv* env,
        jobject /* thiz */,
        jstring userCommand) {
    std::lock_guard<std::mutex> lock(g_engine_mutex);

    if (userCommand == nullptr) {
        return env->NewStringUTF("{\"action\":\"speak\",\"text\":\"I did not catch that.\"}");
    }

    const char* cmdChars = env->GetStringUTFChars(userCommand, nullptr);
    std::string userStr(cmdChars ? cmdChars : "");
    if (cmdChars) {
        env->ReleaseStringUTFChars(userCommand, cmdChars);
    }

#if HAVE_LLAMA_CPP
    if (g_model == nullptr || g_ctx == nullptr) {
        LOGW("nativeInfer called while GGUF model is unloaded; falling back to C++ parser");
        std::string fallback = fallbackRuleBasedJson(userStr);
        return env->NewStringUTF(fallback.c_str());
    }

    // Format prompt with ChatML and prime assistant response with opening brace '{'
    std::string fullPrompt = std::string(kJarvisSystemPrompt) +
                             "<|im_start|>user\n" + userStr + "<|im_end|>\n"
                             "<|im_start|>assistant\n{";

    const llama_vocab* vocab = llama_model_get_vocab(g_model);

    // Clear KV memory from previous turn so each voice command starts fresh inside 512 context
    llama_memory_clear(llama_get_memory(g_ctx), true);

    const int n_prompt_max = static_cast<int>(fullPrompt.size()) + 16;
    std::vector<llama_token> tokens(n_prompt_max);
    int n_tokens = llama_tokenize(
            vocab,
            fullPrompt.c_str(),
            static_cast<int32_t>(fullPrompt.size()),
            tokens.data(),
            static_cast<int32_t>(tokens.size()),
            true,
            true);

    if (n_tokens < 0) {
        tokens.resize(-n_tokens);
        n_tokens = llama_tokenize(
                vocab,
                fullPrompt.c_str(),
                static_cast<int32_t>(fullPrompt.size()),
                tokens.data(),
                static_cast<int32_t>(tokens.size()),
                true,
                true);
    }
    if (n_tokens <= 0) {
        std::string fallback = fallbackRuleBasedJson(userStr);
        return env->NewStringUTF(fallback.c_str());
    }
    tokens.resize(n_tokens);

    // Evaluate prompt in batches of 128 (Galaxy A10 tuned)
    const int n_batch = 128;
    for (int i = 0; i < n_tokens; i += n_batch) {
        int cur_batch_size = std::min(n_batch, n_tokens - i);
        llama_batch batch = llama_batch_get_one(tokens.data() + i, cur_batch_size);
        if (llama_decode(g_ctx, batch) != 0) {
            LOGE("llama_decode failed during prompt evaluation");
            std::string fallback = fallbackRuleBasedJson(userStr);
            return env->NewStringUTF(fallback.c_str());
        }
    }

    std::string generated = "{";
    const int max_new_tokens = 96;

    for (int step = 0; step < max_new_tokens; ++step) {
        llama_token new_token_id = llama_sampler_sample(g_sampler, g_ctx, -1);
        if (llama_vocab_is_eog(vocab, new_token_id)) {
            break;
        }

        char piece[128] = {0};
        int n_piece = llama_token_to_piece(vocab, new_token_id, piece, sizeof(piece) - 1, 0, true);
        if (n_piece > 0) {
            generated.append(piece, n_piece);
        }

        // Stop immediately as soon as the root JSON object closes
        std::string extracted = extractJsonObject(generated);
        if (!extracted.empty()) {
            LOGI("GGUF JSON output: %s", extracted.c_str());
            return env->NewStringUTF(extracted.c_str());
        }

        llama_batch next_batch = llama_batch_get_one(&new_token_id, 1);
        if (llama_decode(g_ctx, next_batch) != 0) {
            break;
        }
    }

    std::string finalJson = extractJsonObject(generated);
    if (!finalJson.empty()) {
        return env->NewStringUTF(finalJson.c_str());
    }

    std::string fallback = fallbackRuleBasedJson(userStr);
    return env->NewStringUTF(fallback.c_str());
#else
    std::string result = fallbackRuleBasedJson(userStr);
    LOGI("JNI Fallback Infer: %s -> %s", userStr.c_str(), result.c_str());
    return env->NewStringUTF(result.c_str());
#endif
}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_engine_LlamaBridge_nativeFreeModel(
        JNIEnv* /* env */,
        jobject /* thiz */) {
    std::lock_guard<std::mutex> lock(g_engine_mutex);

#if HAVE_LLAMA_CPP
    if (g_sampler != nullptr) {
        llama_sampler_free(g_sampler);
        g_sampler = nullptr;
    }
    if (g_ctx != nullptr) {
        llama_free(g_ctx);
        g_ctx = nullptr;
    }
    if (g_model != nullptr) {
        llama_model_free(g_model);
        g_model = nullptr;
    }
    llama_backend_free();
    LOGI("GGUF model and context freed — ~300 MB RAM reclaimed (0 MB Idle Brain)");
#else
    LOGI("nativeFreeModel invoked — Brain state reset to SLEEPING (0 MB Idle Brain)");
#endif
    g_loaded_model_path.clear();
    g_virtual_model_loaded = false;
}

extern "C"
JNIEXPORT jboolean JNICALL
Java_com_example_engine_LlamaBridge_nativeIsModelLoaded(
        JNIEnv* /* env */,
        jobject /* thiz */) {
    std::lock_guard<std::mutex> lock(g_engine_mutex);
#if HAVE_LLAMA_CPP
    return (g_model != nullptr && g_ctx != nullptr) ? JNI_TRUE : JNI_FALSE;
#else
    return g_virtual_model_loaded ? JNI_TRUE : JNI_FALSE;
#endif
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_example_engine_LlamaBridge_nativeGetEngineInfo(
        JNIEnv* env,
        jobject /* thiz */) {
#if HAVE_LLAMA_CPP
    return env->NewStringUTF("JNI C++ llama.cpp Active (n_ctx=512, n_threads=4, n_batch=128)");
#else
    return env->NewStringUTF("JNI C++ Bridge Ready (Upload llama.cpp/ to link GGUF kernels)");
#endif
}
