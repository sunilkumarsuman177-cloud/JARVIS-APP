package com.example

import com.example.engine.LlamaBridge
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun offlineIntentCompiler_generatesValidJsonForAllSchemas() {
        assertTrue(LlamaBridge.compileOfflineIntentJson("turn on wifi").contains("\"action\":\"wifi\""))
        assertTrue(LlamaBridge.compileOfflineIntentJson("turn off bluetooth").contains("\"action\":\"bluetooth\""))
        assertTrue(LlamaBridge.compileOfflineIntentJson("turn on flashlight").contains("\"action\":\"flashlight\""))
        assertTrue(LlamaBridge.compileOfflineIntentJson("enable do not disturb").contains("\"action\":\"dnd\""))
        assertTrue(LlamaBridge.compileOfflineIntentJson("set volume to 75").contains("\"level\":75"))
        assertTrue(LlamaBridge.compileOfflineIntentJson("open whatsapp").contains("\"query\":\"whatsapp\""))
        assertTrue(LlamaBridge.compileOfflineIntentJson("call Mom").contains("\"name\":\"Mom\""))
        assertTrue(LlamaBridge.compileOfflineIntentJson("set alarm for 30 minutes").contains("\"minutes\":30"))
        assertTrue(LlamaBridge.compileOfflineIntentJson("click Send").contains("\"text\":\"Send\""))
        assertTrue(LlamaBridge.compileOfflineIntentJson("scroll down").contains("\"target\":\"scroll_down\""))
        assertTrue(LlamaBridge.compileOfflineIntentJson("who made you").contains("Prince Priyadarshi"))
    }
}
